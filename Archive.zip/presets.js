export function getPresetDefinitions(self) {
    return {
    }
    
}